class Conta:
    def __init__(self, numero = '', saldo = 0.0):
        self.numero = numero
        self.saldo = saldo
